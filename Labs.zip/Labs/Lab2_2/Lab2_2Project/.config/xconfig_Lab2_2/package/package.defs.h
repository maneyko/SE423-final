/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D28
 */

#ifndef xconfig_Lab2_2__
#define xconfig_Lab2_2__



#endif /* xconfig_Lab2_2__ */ 
