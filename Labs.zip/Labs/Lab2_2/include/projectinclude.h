#include "Lab2_2_pe674.h"

 
