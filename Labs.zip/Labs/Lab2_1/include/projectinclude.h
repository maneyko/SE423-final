#include "Lab2_1_pe674.h"

 
