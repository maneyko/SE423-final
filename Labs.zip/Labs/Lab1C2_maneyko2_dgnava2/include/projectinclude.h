#include "Lab1C2_maneyko2_dgnava2_pe674.h"

 
