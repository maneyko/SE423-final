/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D28
 */

#ifndef xconfig_Lab1C2_maneyko2_dgnava2__
#define xconfig_Lab1C2_maneyko2_dgnava2__



#endif /* xconfig_Lab1C2_maneyko2_dgnava2__ */ 
