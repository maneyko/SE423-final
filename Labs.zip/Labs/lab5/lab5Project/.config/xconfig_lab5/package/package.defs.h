/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D28
 */

#ifndef xconfig_lab5__
#define xconfig_lab5__



#endif /* xconfig_lab5__ */ 
