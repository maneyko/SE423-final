/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D28
 */

#ifndef xconfig_lab3_1__
#define xconfig_lab3_1__



#endif /* xconfig_lab3_1__ */ 
