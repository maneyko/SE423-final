#ifndef __28335_INITS_H_
#define __28335_INITS_H_

#include <DSP2833x_Device.h>


// Function prototypes
void pre_init(void);
void post_init(void);

#endif /*28335_INITS_H_*/
