#ifndef USER_PIFUNCS_H_
#define USER_PIFUNCS_H_

void PIVelControl(float vref, float turn);
void PIVelControl_Zero(void);

#endif /*USER_PIFUNCS_H_*/
