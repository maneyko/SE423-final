#ifndef __28335_MCBSP_H_
#define __28335_MCBSP_H_

#include <DSP2833x_Device.h>


// Function prototypes
void McBSP_TX_INTCH1_ISR(void);
void McBSP_RX_INTCH2_ISR(void);

#endif /*28335_MCBSP_H_*/
