#include "Lab1C_maneyko2_dgnava2_pe674.h"

 
