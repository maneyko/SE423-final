#include "Lab1A_pe674.h"

 
